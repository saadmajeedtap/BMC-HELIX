SET COLSEP "^";
SET FEEDBACK OFF;
SET ECHO OFF;
SET PAGES 0;
SET LINESIZE 32767;
SET HEADING OFF;

SPOOL Company.txt
select Company,Company_Type,'' from Com_Company;

SPOOL People_Organization.txt
select  distinct Organization,Department from CTM_People_Organization where Company='Replace_Company_Name';

SPOOL Support_Group.txt
select Support_Organization,Support_Group_Name,case when Support_Group_Role='Help Desk' then 0 else NULL end,case when Vendor_Group=1 then 0 else NULL end,REPLACE(REPLACE(GroupNotificationEmail,CHR(10),';'),CHR(13),';'),'',Description from CTM_Support_Group where Status=1 and Company='Replace_Company_Name' group by Support_Organization,Support_Group_Name,Support_Group_Role,Vendor_Group,GroupNotificationEmail,Description;

SPOOL Location.txt
select max(Region),max(Site_Group),Site,max(REPLACE(REPLACE(Street,CHR(10),' '),CHR(13),' ')),max(Country),max(State_Province),max(City),max(Zip_Postal_Code),max(Site_Alias),max(Description) from SIT_Site_Alias_Company_LookUp where Site=Site_Alias and  Status_STL=1 and Company='Replace_Company_Name' group by Site;

SPOOL People_Template.txt
select Remedy_Login_ID from CTM_People where Remedy_Login_ID is not null and Profile_Status=1 and Company='Replace_Company_Name';

SPOOL Permission_Group.txt
select Permission_Group,viaTIL_License_Type,Remedy_Login_ID from CTM_People_Permission_Groups where Permission_Group_Type = 1 and Permission_Group !='General Access';

SPOOL Support_Group_Association.txt
select Support_Organization, Support_group_name,Default_x,Login_ID from CTM_Support_Group_Association a, CTM_Support_Group b where a.Support_Group_ID=b.Support_Group_ID  and a.Status=1 and Login_ID in (select Remedy_Login_ID from CTM_People where Profile_Status=1 and Company='Replace_Company_Name');

SPOOL Functional_Roles.txt
select Support_Organization, Support_group_name,Support_Group_Association_R001,Login_ID from CTM_Support_Group_Association a, CTM_Support_Group b where a.Support_Group_ID=b.Support_Group_ID and a.Status=1 and Login_ID in (select Remedy_Login_ID from CTM_People where Profile_Status=1 and Company='Replace_Company_Name');

SPOOL People.txt
select Last_Name,First_Name,max(Corporate_ID),max(Internet_E_mail),max(Site),max(Organization),max(Department),max(Remedy_Login_ID),max(Password),max(a.License_Type),max(Remedy_Login_ID) from CTM_People a LEFT OUTER JOIN User_x b on Remedy_Login_ID=Login_Name where Company='Replace_Company_Name' and Profile_Status=1 group by Last_Name,First_Name,Remedy_Login_ID;

SPOOL Additional_Support_Groups.txt
select Login_ID,a.Support_Organization,a.Support_Group_Name from CTM_Support_Group a,CTM_Support_Group_Association b where a.Support_Group_ID=b.Support_Group_ID and b.Status=1 and Login_ID in (select Remedy_Login_ID from CTM_People where Profile_Status=1 and Company='Replace_Company_Name');

SPOOL Additional_Functional_Roles.txt
select Login_ID,a.Support_Organization,a.Support_Group_Name,FunctionalRoleAlias from CTM_Support_Group a,CTM_SupportGroupFunctionalRole b where a.Support_Group_ID=b.Support_Group_ID and b.Status=1 and Login_ID in (select Remedy_Login_ID from CTM_People where Profile_Status=1 and Company='Replace_Company_Name') and a.Company='Replace_Company_Name';

SPOOL Operational_Categorization.txt
select distinct Service_Categorization_Tier_1,Service_Categorization_Tier_2,Service_Categorization_Tier_3,'' from CFG_Service_Catalog;

SPOOL Product_Categorization.txt
select distinct Menu_Category,b.Menu_Label_1,Product_Categorization_Tier_1,Product_Categorization_Tier_2,Product_Categorization_Tier_3,Product_Name,Manufacturer,Suite_Definition_, case when Company = '- Global -' then 0 else NULL end from PCT_ProductCompanyAssocLookup a, PCT_MenuItems b where b.Menu_Type = 'CITYPE' and b.Menu_Value_1 = a.CategorizationSchemaKeyword and b.Locale = 'en' and b.Menu_Label_1 != 'Service';

SPOOL Assignment.txt
select distinct Assignment_Event,Support_Organization,Assigned_Group,Organization,Department,Region,Site_Group,Site,Product_Categorization_Tier_1,Product_Categorization_Tier_2,Product_Categorization_Tier_3,Product_Categorization_Tier_1,Product_Categorization_Tier_2,Product_Categorization_Tier_3,Product_Name,Description from CFG_Assignment where Company='Replace_Company_Name';
quit